/*
 Name:		Black_Sheep.cpp
 Updated:	11/25/2018 4:14:55 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the body class that builds the specific Black Sheep story. It
contains details like the story's name and lines that make up the story.  */
#include "Black_Sheep.h"

	// overriden virtual function
	void Black_Sheep::buildStory() {
		storyLines[0] = "    Baa, baa, black sheep  ";
		storyLines[1] = "  Have you any wool?  ";
		storyLines[2] = "    Yes sir, yes sir, three bags full.  ";
		storyLines[3] = "  One for the master,";
		storyLines[4] = "    And one for the dame,";
		storyLines[5] = "  And one for the little boy";
		storyLines[6] = "   Who lives down the lane.";
	}
	bool Black_Sheep::checkAngles(float a, float b) {
		return (a > 25 && b < 10);
	}