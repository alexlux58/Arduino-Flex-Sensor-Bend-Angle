/*
 Name:		Black_Sheep.h
 Updated:	11/25/2018 4:14:55 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the header class that builds the specific Black Sheep story. It
contains details like the story's name and lines that make up the story.  */
#pragma once
#include "story.h"
#include "Arduino.h"

// derived class that contains a story of Black Sheep
class Black_Sheep : public story
{
public:
	// stores the given story line by line
	String storyLines[7];
	// constructor
	Black_Sheep(String name) : story(name) {};
	// overriden virtual function
	void buildStory();
	bool checkAngles(float a, float b);
};