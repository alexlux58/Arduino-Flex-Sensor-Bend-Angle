/*
 Name:		story.h
 Updated:	11/24/2018 6:53:14 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the header class that builds each story. It is an abstract class
that contains details like the story's name and a way to build each story.  */
#pragma once
#include "Arduino.h"
#include <LiquidCrystal.h>
#include "Finger.h"

// Abstract Class Story
class story
{
private:
	String name;
public:
	// pure virtual function 
	virtual void buildStory() = 0;

	// Two string variables that print a welcome prompt.
	story(String n);
	// assessor for story name
	String getName();
};