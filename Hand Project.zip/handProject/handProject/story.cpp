/*
 Name:		story.cpp
 Updated:	11/24/2018 6:53:14 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the body class that builds each story. It is an abstract class
that contains details like the story's name and a way to build each story.  */
#include "story.h"



	// Two string variables that print a welcome prompt.
	story::story(String n) {
		this->name = n;
	}
	

	// assessor for story name
	String story::getName() {
		return name;
	}