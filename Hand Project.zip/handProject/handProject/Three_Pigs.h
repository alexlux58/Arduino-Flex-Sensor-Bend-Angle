/*
 Name:		Three_Pigs.h
 Updated:	11/25/2018 3:05:22 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the header class that builds the specific Three Pigs story. It
contains details like the story's name and lines that make up the story.  */
#pragma once
#include "story.h"
#include "Arduino.h"

// derived class that contains a story of 3 pigs.
class Three_Pigs : public story
{
public:
	// stores the given story line by line
	String storyLines[6];
	// constructor
	Three_Pigs(String name) : story(name) {};
	// overriden virtual function
	void buildStory();

	bool checkAngles(float a);
	bool checkAngles(float a, String n);
	bool checkAngles(float a, float b);
	bool checkAngles(float a, float b, float c);
	bool checkAngles(float a, float b, float c, float d);
	bool checkAngles(float a, float b, float c, float d, float e);
};
