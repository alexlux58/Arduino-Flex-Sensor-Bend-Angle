/*
 Name:		Finger.h
 Updated:	11/24/2018 5:44:30 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the header class that builds each finger. It stores and allows
 retrieval of various details pertaining to each finger, such as angle,
 or bend resistance.
*/
#pragma once
#include "Arduino.h"
class Finger {
	private:
		int fingerNum; // Pin # connected to each voltage divider output
		String name; // name of the finger
		const float V = 4.99; // Measured voltage for the Arduino 5V angleIndex
		const float Resistor = 100000.0; // Resitance of a 100k Resistor
		const float STRAIGHT_RESISTANCE = 28000.0; // resistance when sensor is straight
		const float BEND_RESISTANCE = 89000.0; // resistance when sensor is at 90 degrees
		int flexADC; // Reads 800 flexed, 420 bent
		// Calculates voltage: Analog * Voltage from Arduino / 1023.0 (max analog input)
		float flex_Voltage;
		// Calculates resistance: resistor * (voltage from Arduino / flex sensor voltage - 1.0)
		float flex_Resistance;
		// Use calcualted resistance to estimate the sensor's bend angle
		float angle;
public:
	// assessors
	const float getVoltage();
	const float getResistor();
	const float get_Straight_Resist();
	const float get_Bend_Resist();
	int getFinger();
	int getFlexADC();
	float getFlex_Voltage();
	float getFlex_Resistance();
	float getAngle();

	// constructor
	Finger(String n, int f);

	//checks and updates info on sensor
	void checkInfo();
};