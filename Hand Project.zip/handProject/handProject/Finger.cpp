/*
 Name:		Finger.cpp
 Updated:	11/24/2018 5:44:30 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the body class that builds each finger. It stores and allows
 retrieval of various details pertaining to each finger, such as angle,
 or bend resistance.
*/
#include "Finger.h"

const float Finger::getVoltage(){
	return V;
}
const float Finger::getResistor(){
	return Resistor;
	};
const float Finger::get_Straight_Resist() {
	return STRAIGHT_RESISTANCE; 
};
const float Finger::get_Bend_Resist() { 
	return BEND_RESISTANCE;
};
int Finger::getFinger() { 
	return fingerNum; 
};
int Finger::getFlexADC() { 
	return flexADC; 
};
float Finger::getFlex_Voltage() {
	return flex_Voltage; 
};
float Finger::getFlex_Resistance() {
	return flex_Resistance; 
};
float Finger::getAngle() { 
	return angle; 
};

Finger::Finger(String n, int f) {
	this->name = n;
	this->fingerNum = f;
}

void Finger::checkInfo() {
	flexADC = analogRead(fingerNum);
	flex_Voltage = flexADC * V / 1023.0;
	flex_Resistance = Resistor * (V / flex_Voltage - 1.0);
	angle = map(flex_Resistance, STRAIGHT_RESISTANCE, BEND_RESISTANCE, 0, 90.0);
	Serial.println(name + " Data");
	Serial.println("Resistance " + String(flex_Resistance) + " ohms");
	Serial.println("Bend " + String(angle) + " degrees");
	Serial.println();
	delay(900);
}