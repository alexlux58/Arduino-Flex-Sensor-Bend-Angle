/*
 Name:		Three_Pigs.cpp
 Updated:	11/25/2018 3:05:22 PM
 Author:	Alex, Tyler, Preston, Emerson

 This is the body class that builds the specific Three Pigs story. It
contains details like the story's name and lines that make up the story.  */
#include "Three_Pigs.h"

	// overriden virtual function
	void Three_Pigs::buildStory() {
		storyLines[0] = ("   This little piggy");
		storyLines[1] = (" went to the market,");
		storyLines[2] = (" stayed home,");
		storyLines[3] = (" had roast beef,");
		storyLines[4] = (" had none.");
		storyLines[5] = ("         went ... Wee, Wee, Wee, all the way home");
	}

	bool Three_Pigs::checkAngles(float a) {
		return (a > 10 && a < 26);
	}
	bool Three_Pigs::checkAngles(float a, String n) {
		return (a > 26);
	}
	bool Three_Pigs::checkAngles(float a, float b) {
		return (a > 26 && b > 26);
	}
	bool Three_Pigs::checkAngles(float a, float b, float c) {
		return (a > 26 && b > 26 && c > 26);
	}
	bool Three_Pigs::checkAngles(float a, float b, float c, float d) {
		return (a > 26 && b > 26 && c > 26 && d > 26);
	}
	bool Three_Pigs::checkAngles(float a, float b, float c, float d, float e) {
		return (a > 26 && b > 26 && c > 26 && d > 26 && e > 26);
	}