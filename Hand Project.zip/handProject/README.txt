ARDUINO GLOVE SENSOR WITH LCD MONITOR

Step 1: Use Image1.JPG and Image2.JPG to connect the glove and connect the lcd monitor

Step 2:	Download Microsoft Visual Studio : https://visualstudio.microsoft.com/

	along with the Arduino IDE: https://marketplace.visualstudio.com/items?itemName=VisualMicro.ArduinoIDEforVisualStudio
Step 3: Open Microsft Visual Studio and create a new project using all the given header, cpp, and the ino files. Ensure that 
	header files are stored in the Solution Explorer under the Header files tab and all other files (cpp and ino) are
	stored under the Source files tab. 

Step 4: Ensure that the glove and lcd monitor are connected to the circuit board and the circuit board is connected to the
	computer via USB.

Step 5: Run the file by hitting the play button on the top right side of the coding screen. If everything worked,
	two sub-menus should appear. The smaller sub menu shows that the connection between the circuit board, lcd monitor, and 
	glove were successful. The second menu displays the angles of each finger bent as a means of checking output and
	understanding what's happening as you bend each finger. 

Step 6: The lcd should now display the intro message of the story. Continue bending the fingers (beginning with your thumb and
	waiting for the scrolling to finish before bending the next finger) to have the hand read the entire story to you.

	note: the initial bend of the thumb allows the user to pick between two pre-loaded stories. 
 